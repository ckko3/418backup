#!/bin/sh

rm -rf data
rm mydedup.meta
