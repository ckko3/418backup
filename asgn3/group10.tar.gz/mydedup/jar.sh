#!/bin/bash

jar cf mydedup.jar -C build .
